ServerEvents.recipes(event => {
    event.custom({
      "type": "ars_nouveau:enchanting_apparatus",
      "reagent": {
        "item": "ars_nouveau:spell_parchment" // The central item in the Enchanting Apparatus
      },
      "pedestalItems": [
        {
          "item": "irons_spellbooks:lightning_rune" // Item on the first pedestal
        },
        {
          "item": "minecraft:lightning_rod" // Item on the second pedestal
        },
        {
          "item": "irons_spellbooks:lightning_rune" // Item on the third pedestal
        },
        {
          "item": "botania:rune_mana" // Item on the fourth pedestal
        },
        {
          "item": "botania:rune_mana" // Item on the fifth pedestal
        },  
        {
          "item": "minecraft:iron_ingot" // Item on the sixth pedestal
        },
        {
          "item": "irons_spellbooks:lightning_rune" // Item on the seventh pedestal
        },
        {
          "item": "minecraft:iron_ingot" // Item on the eighth pedestal
        }
      ],
      "output": {
      "item": "irons_spellbooks:scroll", // The generic scroll item from Iron's Spellbooks
      "nbt": {
        "ISB_Spells": {
          "data": [
            {
              "id": "irons_spellbooks:ascension", // ID for the Ascension spell
              "index": 0, // Index position in the spell data array
              "level": 1, // Level of the spell, adjust as needed
              "locked": 1 // Whether the spell is locked, adjust if necessary
            }
          ],
          "maxSpells": 1, // Maximum number of spells
          "mustEquip": 0, // Whether the scroll must be equipped
          "spellWheel": 0 // Whether the spell wheel is used
        }
      }
    },
    "sourceCost": 5000, // Source cost for the recipe, adjust as needed
    "count": 1 // Output count
  });
});